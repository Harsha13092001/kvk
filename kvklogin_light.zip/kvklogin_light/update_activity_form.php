<?php
include_once 'database/config.php';

if(!isset($_SESSION['kvk_id']))
{
   header("Location:index");
   
}
 // Make sure to start the session
$id = $_GET['id'];
// Include the configuration file with the database connection

if(isset($_POST['update']))
{
    $activity_title = $_POST["activity_title"];
    $target_no = $_POST["Target_No"];
    $target_no_of_trails = $_POST["Target_No_of_Trials"];
    $completed_no = $_POST["Completed_Nos"];
    $completed_no_of_trails = $_POST["Completed_No_of_trials"];
    $ongoing_no = $_POST["Ongoing_No"];
    $ongoing_no_of_trails = $_POST["Ongoing_No_of_Trials"];
    $yet_to_start_no = $_POST["Yet_to_start_No"];
    $remarks = $_POST["Remarks"];
    
    $timestamp = date("Y-m-d H:i:s");
   
    $res=$conn->query("UPDATE `activity_form` SET `activity_title`='$activity_title', `Target_No`='$target_no', `Target_No_of_Trials`='$target_no_of_trails', `Completed_Nos`='$completed_no', `Completed_No_of_trials`='$completed_no_of_trails', `Ongoing_No`='$ongoing_no', `Ongoing_No_of_Trials`='$ongoing_no_of_trails', `Yet_to_start_No`='$yet_to_start_no', `Remarks`='$remarks', `updated_on`='$timestamp' WHERE `id`='$id'");
    $rs=mysqli_affected_rows($conn);
    if($rs)
    {
        ?>
        <script type="text/javascript">
        alert("Activity details Updated successfully");
		window.location="read_activity_form";
        </script>
     <?php
    }
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <title><?php echo $title ?></title>
    <!-- Custom CSS -->
    
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="header-fix fix-sidebar">
<?php
    $query=mysqli_query($conn,"select * from activity_form where `id`='$id'")or die(mysqli_error($conn));
    $row=mysqli_fetch_array($query);
    ?>
    <!-- Main wrapper  -->
    <div id="main-wrapper">
        <!-- header header  -->
        <?php include("includes/header.php");?>
        <!-- End header header -->
        <!-- Left Sidebar  -->
        <?php include("includes/sidebar.php");?>
        <!-- End Left Sidebar  -->
        <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">KVK</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">kvk details</a></li>
                        <li class="breadcrumb-item active">view kvk</li>
                    </ol>
                </div>
            </div>
            <!-- End Bread crumb -->
            <!-- Container fluid  -->
            <div class="container-fluid">
                <!-- Start Page Content -->
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-validation">
                                    <form class="form-valide" action="" method="post">
                                    <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-username"> Activity Title: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" value="<?php echo $row['activity_title']?>" name="activity_title" >
                                            </div>
                                        </div>
                                    <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-username">Target No: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"  value="<?php echo $row['Target_No']?>" name="Target_No">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Target_No_of_Trials:<span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"  name="Target_No_of_Trials"  value="<?php echo $row['Target_No_of_Trials']?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-password">Completed_Nos: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" name="Completed_Nos" value="<?php echo $row['Completed_Nos']?>" >
                                            </div>
                                        </div>
                                      
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="address">Completed_No_of_trials: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"  name="Completed_No_of_trials" value="<?php echo $row['Completed_No_of_trials']?>" >
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="address">Ongoing_No: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"  name="Ongoing_No"  value="<?php echo $row['Ongoing_No']?>" placeholder="Your district..">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="address">Ongoing_No_of_Trials: <span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"  name="Ongoing_No_of_Trials" value="<?php echo $row['Ongoing_No_of_Trials']?>" >
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="mobile">Yet_to_start_No:<span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control"value="<?php echo $row['Yet_to_start_No']?>" name="Yet_to_start_No"  >
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label"  for="dropdownInput">Remarks:<span class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                            <select id="dropdownInput" name="Remarks" required>
                                                    <option value="<?php echo $row['Remarks'] ?>"><?php echo $row['Remarks'] ?></option>
                                                    <option value="in_progress">In Progress</option>
                                                    <option value="pending">Pending</option>
                                                    <option value="completed">Done</option>
                                        
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-lg-8 ml-auto">
                                                <button type="submit" name="update" value="Update Activity" class="btn btn-primary">Update</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End PAge Content -->
            </div>
            <!-- End Container fluid  -->
            <!-- footer -->
            <?php include('includes/footer.php');?>
            <!-- End footer -->
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- End Wrapper -->
    <!-- All Jquery -->
    <script src="js/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


    <!-- Form validation -->
    <script src="js/lib/form-validation/jquery.validate.min.js"></script>
    <script src="js/lib/form-validation/jquery.validate-init.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>

</body>

</html>