<div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebar-menu">
                        <li class="nav-devider"></li>
                     
                        <li class="nav-label">Home</li>
                        <li> <a  href="dashboard" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Dashboard </span></a>
                        
                        </li>
                        <li class="nav-label">ACTIVITY_FORM DETAILS</li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-suitcase"></i><span class="hide-menu">Activity form</span></a>
                            <ul aria-expanded="false" class="collapse">
                            <li><a href="add_activity_form">ADD ACTIVITY FORM</a></li>
                                <li><a href="view_activity_form">VIEW ACTIVITY FORM</a></li>
                              
                            </ul>
                        </li>

                        <li class="nav-label">Chart</li>
                        <li> <a  href="barchart" aria-expanded="false"><i class="fa fa-bar-chart"></i><span class="hide-menu">Stacked Chart</span></a>

                        
                    
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>